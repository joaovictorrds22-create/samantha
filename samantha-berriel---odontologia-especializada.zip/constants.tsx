
import React from 'react';
import { 
  Stethoscope, 
  Sparkles, 
  Activity, 
  Baby, 
  ShieldCheck, 
  Zap, 
  MapPin, 
  Smile, 
  Clock 
} from 'lucide-react';
import { Specialty, Benefit } from './types';

export const SPECIALTIES: Specialty[] = [
  {
    title: "Estética Dental",
    description: "Transformação do sorriso com Clareamento Dental, Facetas, Lentes de Contato e Restaurações estéticas de alta precisão.",
    icon: <Sparkles className="w-6 h-6" />
  },
  {
    title: "Ortodontia Moderna",
    description: "Correção do posicionamento dentário com Alinhadores Ortodônticos, Aparelhos Auto-ligados, fixos e removíveis.",
    icon: <Activity className="w-6 h-6" />
  },
  {
    title: "Implantes & Cirurgia",
    description: "Reabilitação oral completa com Implantodontia e Cirurgia Buco-Maxilo-Facial para casos complexos e funcionais.",
    icon: <ShieldCheck className="w-6 h-6" />
  },
  {
    title: "Endo & Periodontia",
    description: "Tratamentos especializados de canal (Endodontia) e saúde das gengivas (Periodontia) com tecnologia de Laserterapia.",
    icon: <Zap className="w-6 h-6" />
  },
  {
    title: "Odontopediatria",
    description: "Atendimento lúdico e preventivo dedicado à saúde bucal das crianças, garantindo um futuro com sorrisos saudáveis.",
    icon: <Baby className="w-6 h-6" />
  },
  {
    title: "Urgência & Geral",
    description: "Pronto Socorro odontológico e Clínica Geral para diagnósticos precisos e alívio imediato da dor.",
    icon: <Clock className="w-6 h-6" />
  }
];

export const BENEFITS: Benefit[] = [
  {
    title: "Tecnologia e Inovação",
    description: "Utilizamos as técnicas mais modernas como Laserterapia e Alinhadores Invisíveis para tratamentos mais rápidos e confortáveis."
  },
  {
    title: "Atendimento Multidisciplinar",
    description: "Todas as especialidades em um só lugar: da Ortodontia à Implantodontia, cuidamos de cada etapa do seu tratamento."
  },
  {
    title: "Localização Privilegiada",
    description: "Estamos localizados no coração da Mooca (Rua Guaimbé), com fácil acesso e ambiente planejado para o seu conforto."
  },
  {
    title: "Foco no Bem-Estar",
    description: "Abordagem humanizada para pacientes de todas as idades, incluindo cuidados especiais em odontopediatria e urgências."
  }
];
