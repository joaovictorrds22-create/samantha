
import React, { useState, useEffect, useRef } from 'react';
import { 
  Menu, 
  X, 
  ChevronRight, 
  MessageCircle, 
  ArrowUpRight, 
  CheckCircle2, 
  MapPin, 
  Phone,
  Clock,
  Sparkles
} from 'lucide-react';
import { SPECIALTIES, BENEFITS } from './constants';

const App: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Lógica para observar elementos e disparar animação de "reveal"
  useEffect(() => {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('active');
        }
      });
    }, { threshold: 0.1 });

    const reveals = document.querySelectorAll('.reveal');
    reveals.forEach(el => observer.observe(el));

    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      reveals.forEach(el => observer.unobserve(el));
    };
  }, []);

  const profileUrl = "https://www.boaconsulta.com/especialista/samantha-berriel-60076d8a1dffde005e000038";
  const phoneNumber = "(11) 99255-5301";
  const address = "Rua Guaimbé, 229, Mooca, São Paulo - SP";

  const closeMenu = () => setIsMenuOpen(false);

  const scrollToSection = (e: React.MouseEvent<HTMLAnchorElement>, id: string) => {
    e.preventDefault();
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
    closeMenu();
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 overflow-x-hidden">
      {/* Background Shapes */}
      <div className="fixed inset-0 pointer-events-none -z-10 overflow-hidden">
        <div className="absolute top-[10%] -left-20 w-96 h-96 bg-cyan-100/40 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-[20%] -right-20 w-[500px] h-[500px] bg-cyan-50/50 rounded-full blur-3xl animate-float-delayed"></div>
      </div>

      {/* Navigation */}
      <nav className={`fixed w-full z-50 transition-all duration-500 ${scrolled ? 'bg-white/90 backdrop-blur-md shadow-lg py-3' : 'bg-transparent py-5'}`}>
        <div className="container mx-auto px-6 flex justify-between items-center">
          <div className="flex items-center group cursor-pointer" onClick={(e) => scrollToSection(e as any, 'root')}>
            <div className="w-10 h-10 bg-cyan-600 rounded-lg flex items-center justify-center text-white font-serif font-bold text-xl group-hover:rotate-12 transition-transform duration-300">SB</div>
            <div className="hidden sm:block border-l border-slate-300 h-6 mx-3"></div>
            <span className={`text-lg font-medium tracking-tight transition-colors duration-300 ${scrolled ? 'text-slate-900' : 'text-slate-800'}`}>Samantha Berriel</span>
          </div>

          <div className="hidden md:flex items-center space-x-6">
            {['sobre', 'servicos', 'beneficios', 'localizacao'].map((item) => (
              <a 
                key={item}
                href={`#${item}`} 
                onClick={(e) => scrollToSection(e, item)} 
                className="relative hover:text-cyan-600 transition-colors font-medium capitalize group py-2"
              >
                {item}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-cyan-600 transition-all duration-300 group-hover:w-full"></span>
              </a>
            ))}
            <a 
              href={profileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-cyan-600 text-white px-6 py-2.5 rounded-full font-bold hover:bg-cyan-700 transition-all transform hover:scale-105 shadow-md active:scale-95"
            >
              Agendar Online
            </a>
          </div>

          <button className="md:hidden p-2 text-slate-800" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>

        {/* Mobile Menu Content */}
        {isMenuOpen && (
          <div className="md:hidden bg-white/95 backdrop-blur-lg border-b absolute w-full left-0 py-8 px-6 space-y-4 shadow-2xl animate-in slide-in-from-top duration-300">
            {['sobre', 'servicos', 'beneficios', 'localizacao'].map((item) => (
              <a key={item} href={`#${item}`} onClick={(e) => scrollToSection(e, item)} className="block text-xl font-bold text-slate-800 capitalize border-b border-slate-50 pb-2">{item}</a>
            ))}
            <a href={profileUrl} target="_blank" onClick={closeMenu} className="block bg-cyan-600 text-white px-6 py-4 rounded-2xl font-bold text-center text-lg">Agendar Agora</a>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
        <div className="container mx-auto px-6 flex flex-col lg:flex-row items-center">
          <div className="lg:w-1/2 space-y-8 text-center lg:text-left reveal active">
            <div className="inline-flex items-center bg-cyan-100 text-cyan-800 px-4 py-1.5 rounded-full text-xs font-bold tracking-widest uppercase animate-pulse">
              <Sparkles size={14} className="mr-2" />
              Excelência Odontológica
            </div>
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-slate-900 leading-[1.1]">
              O sorriso que <br/>
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-600 to-cyan-400">você merece.</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-xl mx-auto lg:mx-0 leading-relaxed">
              Tratamentos modernos e atendimento humanizado na Mooca. Tecnologia de ponta para sua saúde e estética bucal.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start space-y-4 sm:space-y-0 sm:space-x-4 pt-6">
              <a 
                href={profileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full sm:w-auto bg-slate-900 text-white px-10 py-5 rounded-2xl font-bold text-lg hover:bg-cyan-700 shadow-2xl transition-all transform hover:-translate-y-1 flex items-center justify-center group"
              >
                <span>Agendar Consulta</span>
                <ChevronRight size={20} className="ml-2 group-hover:translate-x-1 transition-transform" />
              </a>
              <a 
                href={`https://wa.me/55${phoneNumber.replace(/\D/g, '')}`}
                target="_blank"
                className="w-full sm:w-auto bg-white text-slate-700 border border-slate-200 px-10 py-5 rounded-2xl font-bold text-lg hover:bg-slate-50 transition-all flex items-center justify-center space-x-2"
              >
                <MessageCircle size={22} className="text-green-500" />
                <span>WhatsApp</span>
              </a>
            </div>
          </div>
          <div className="lg:w-1/2 mt-16 lg:mt-0 relative px-6 reveal active transition-delay-300">
            <div className="relative z-10 rounded-[2.5rem] overflow-hidden shadow-[0_50px_100px_-20px_rgba(0,0,0,0.2)] transform hover:scale-[1.02] transition-transform duration-700">
              <img 
                src="https://images.unsplash.com/photo-1606811841689-23dfddce3e95?q=80&w=1000&auto=format&fit=crop" 
                alt="Consultório Odontológico Moderno" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-cyan-900/20 to-transparent"></div>
            </div>
            {/* Badge flutuante */}
            <div className="absolute -bottom-8 -left-2 sm:-left-10 bg-white p-6 rounded-3xl shadow-2xl z-20 border border-cyan-50 animate-float">
              <div className="flex items-center space-x-4">
                <div className="bg-cyan-600 p-3 rounded-2xl text-white">
                  <CheckCircle2 size={24} />
                </div>
                <div>
                  <p className="font-bold text-slate-900 text-lg leading-tight">100% Digital</p>
                  <p className="text-sm text-slate-500">Tecnologia avançada</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="bg-white py-16 border-y border-slate-100 overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            {[
              { label: "Registro Profissional", val: "CRO-SP" },
              { label: "Localização Mooca", val: "Rua Guaimbé, 229" },
              { label: "Atendimento Especializado", val: "Urgência & Estética" }
            ].map((stat, i) => (
              <div key={i} className="reveal" style={{ transitionDelay: `${i * 150}ms` }}>
                <h3 className="text-3xl font-serif font-bold text-cyan-700 mb-1">{stat.val}</h3>
                <p className="text-slate-400 uppercase tracking-[0.2em] text-xs font-bold">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="sobre" className="py-32 bg-slate-50 scroll-mt-24">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row gap-20 items-center">
            <div className="md:w-1/2 reveal">
              <div className="w-16 h-1.5 bg-cyan-600 mb-8 rounded-full"></div>
              <h2 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 mb-8 leading-tight">A arte de cuidar <br/>do seu sorriso.</h2>
              <div className="space-y-6 text-slate-600 text-lg leading-relaxed">
                <p>
                  Dra. Samantha Berriel combina precisão técnica com uma visão estética apurada. No coração da Mooca, seu consultório foi planejado para oferecer uma experiência odontológica sem medo e com resultados supreendentes.
                </p>
                <p>
                  Especialista em <strong>Ortodontia e Odontologia Estética</strong>, utiliza alinhadores invisíveis e laserterapia para proporcionar tratamentos rápidos, indolores e altamente eficazes.
                </p>
              </div>
              <div className="mt-12 flex flex-wrap gap-4">
                <div className="bg-white px-6 py-4 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-3 hover:shadow-md transition-shadow">
                   <div className="w-2 h-2 rounded-full bg-cyan-500"></div>
                   <span className="font-bold text-slate-700">Ortodontia Digital</span>
                </div>
                <div className="bg-white px-6 py-4 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-3 hover:shadow-md transition-shadow">
                   <div className="w-2 h-2 rounded-full bg-cyan-500"></div>
                   <span className="font-bold text-slate-700">Estética Facial/Dental</span>
                </div>
              </div>
            </div>
            <div className="md:w-1/2 relative reveal">
               <div className="aspect-[4/5] bg-cyan-100 rounded-[3rem] overflow-hidden shadow-2xl hover-shine">
                  <img src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?q=80&w=800&auto=format&fit=crop" alt="Samantha Berriel - Dentista" className="w-full h-full object-cover transform hover:scale-110 transition-transform duration-[2s]" />
               </div>
               <div className="absolute -bottom-10 -right-4 bg-cyan-700 text-white p-10 rounded-[2.5rem] hidden lg:block max-w-xs shadow-2xl">
                  <p className="text-xl font-medium italic mb-2">"O sorriso é a janela da alma."</p>
                  <p className="text-cyan-200 text-sm font-bold uppercase tracking-widest">Dra. Samantha Berriel</p>
               </div>
            </div>
          </div>
        </div>
      </section>

      {/* Specialties */}
      <section id="servicos" className="py-32 bg-white scroll-mt-24 overflow-hidden">
        <div className="container mx-auto px-6">
          <div className="text-center mb-20 space-y-4 reveal">
            <h2 className="text-cyan-600 font-bold tracking-[0.3em] uppercase text-sm">Nossas Soluções</h2>
            <h3 className="text-4xl md:text-5xl font-serif font-bold text-slate-900">Especialidades</h3>
            <div className="w-24 h-1.5 bg-cyan-100 mx-auto rounded-full"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {SPECIALTIES.map((spec, idx) => (
              <div 
                key={idx} 
                className="group p-10 bg-slate-50 rounded-[2.5rem] border border-slate-100 hover:bg-white hover:shadow-[0_30px_60px_-15px_rgba(0,0,0,0.1)] hover:-translate-y-3 transition-all duration-500 reveal"
                style={{ transitionDelay: `${idx * 100}ms` }}
              >
                <div className="bg-white w-16 h-16 rounded-2xl flex items-center justify-center text-cyan-600 shadow-sm mb-8 group-hover:bg-cyan-600 group-hover:text-white transition-all duration-500 group-hover:rotate-[360deg]">
                  {spec.icon}
                </div>
                <h4 className="text-2xl font-bold text-slate-900 mb-4">{spec.title}</h4>
                <p className="text-slate-500 leading-relaxed text-lg">{spec.description}</p>
                <div className="mt-6 w-0 group-hover:w-full h-0.5 bg-cyan-600/30 transition-all duration-700"></div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section id="beneficios" className="py-32 bg-slate-50 scroll-mt-24">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-24">
            <div className="lg:w-1/3 reveal">
              <h2 className="text-cyan-600 font-bold tracking-[0.2em] uppercase text-sm mb-6">Porque nos escolher</h2>
              <h3 className="text-4xl md:text-5xl font-serif font-bold text-slate-900 mb-8 leading-tight">Onde a tecnologia encontra o cuidado.</h3>
              <p className="text-slate-500 text-xl leading-relaxed mb-10">
                Criamos um ecossistema de saúde bucal focado no seu conforto e na agilidade dos resultados.
              </p>
              <a 
                href={profileUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center space-x-3 text-cyan-700 font-black text-lg hover:text-cyan-900 transition-colors group"
              >
                <span>Explorar agenda online</span>
                <ArrowUpRight size={24} className="group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
              </a>
            </div>
            <div className="lg:w-2/3 grid grid-cols-1 sm:grid-cols-2 gap-8">
              {BENEFITS.map((benefit, idx) => (
                <div 
                  key={idx} 
                  className="bg-white p-10 rounded-[2rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-500 reveal"
                  style={{ transitionDelay: `${idx * 150}ms` }}
                >
                  <div className="w-12 h-12 bg-cyan-50 rounded-xl flex items-center justify-center text-cyan-600 mb-6 font-bold">0{idx+1}</div>
                  <h4 className="text-2xl font-bold text-slate-900 mb-4">{benefit.title}</h4>
                  <p className="text-slate-600 leading-relaxed text-lg">{benefit.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section id="localizacao" className="py-32 bg-slate-950 text-white overflow-hidden scroll-mt-24">
        <div className="container mx-auto px-6">
          <div className="flex flex-col lg:flex-row gap-20 items-center">
            <div className="lg:w-1/2 space-y-10 reveal">
              <h2 className="text-cyan-400 font-bold tracking-[0.2em] uppercase text-sm">Visite-nos</h2>
              <h3 className="text-4xl md:text-6xl font-serif font-bold leading-tight">Consultório <br/><span className="text-cyan-500">Mooca</span></h3>
              
              <div className="space-y-8">
                {[
                  { icon: <MapPin />, title: "Endereço", text: address },
                  { icon: <Phone />, title: "Telefone", text: phoneNumber },
                  { icon: <Clock />, title: "Horários", text: "Seg a Sex: 08h - 18h" }
                ].map((item, i) => (
                  <div key={i} className="flex items-start space-x-6 group">
                    <div className="bg-slate-900 p-4 rounded-2xl text-cyan-400 group-hover:bg-cyan-600 group-hover:text-white transition-colors duration-300">
                      {item.icon}
                    </div>
                    <div>
                      <h5 className="font-bold text-xl mb-1">{item.title}</h5>
                      <p className="text-slate-400 text-lg">{item.text}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <a 
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`}
                target="_blank"
                className="inline-block bg-white text-slate-950 px-10 py-5 rounded-2xl font-black text-lg hover:bg-cyan-500 hover:text-white transition-all transform hover:scale-105"
              >
                Abrir no Google Maps
              </a>
            </div>
            
            <div className="lg:w-1/2 w-full aspect-square md:aspect-video rounded-[3rem] overflow-hidden relative reveal">
                <div className="absolute inset-0 bg-cyan-900/40 mix-blend-multiply z-10 pointer-events-none"></div>
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.4064361005!2d-46.5912447!3d-23.5538466!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce593297a7d49f%3A0xc3f3453303108c7a!2sR.%20Guaimb%C3%A9%2C%20229%20-%20Mooca%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2003118-030!5e0!3m2!1spt-BR!2sbr!4v1715421234567!5m2!1spt-BR!2sbr" 
                  className="w-full h-full border-0 grayscale invert brightness-90 opacity-80" 
                  allowFullScreen 
                  loading="lazy" 
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
                <div className="absolute inset-0 flex items-center justify-center z-20 pointer-events-none">
                   <div className="w-12 h-12 bg-white rounded-full shadow-2xl animate-ping opacity-20"></div>
                </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-32 bg-white reveal">
        <div className="container mx-auto px-6">
          <div className="bg-gradient-to-br from-cyan-600 to-cyan-800 rounded-[3.5rem] p-12 md:p-24 text-center text-white relative overflow-hidden shadow-[0_50px_100px_-20px_rgba(8,145,178,0.4)]">
            <div className="relative z-10 max-w-4xl mx-auto space-y-10">
              <h3 className="text-4xl md:text-6xl font-serif font-bold leading-tight">O seu novo sorriso começa <br/>com um clique.</h3>
              <p className="text-xl md:text-2xl text-cyan-50 font-medium">
                Agendamento simplificado e imediato. Escolha o melhor horário para sua avaliação na Mooca.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 pt-8">
                <a 
                  href={profileUrl}
                  target="_blank"
                  className="w-full sm:w-auto bg-white text-cyan-800 px-12 py-6 rounded-[2rem] font-black text-xl hover:bg-slate-900 hover:text-white shadow-2xl transition-all transform hover:scale-105 active:scale-95"
                >
                  Marcar Consulta Agora
                </a>
              </div>
            </div>
            {/* Elementos decorativos animados no fundo do CTA */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -mr-32 -mt-32 blur-3xl animate-float"></div>
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-cyan-400/20 rounded-full -ml-24 -mb-24 blur-3xl animate-float-delayed"></div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-50 py-20 border-t border-slate-100">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-start mb-16 gap-12">
            <div className="max-w-sm space-y-6">
              <div className="flex items-center space-x-3">
                <div className="w-12 h-12 bg-cyan-600 rounded-xl flex items-center justify-center text-white font-serif font-bold text-2xl">SB</div>
                <span className="text-2xl font-bold">Samantha Berriel</span>
              </div>
              <p className="text-slate-400 text-lg leading-relaxed">
                Transformando vidas através de sorrisos saudáveis e estéticos. Odontologia de alta performance na Mooca.
              </p>
            </div>
            <div className="grid grid-cols-2 gap-12 sm:gap-24">
              <div className="space-y-6">
                <h5 className="font-bold text-slate-900 uppercase tracking-widest text-sm">Navegação</h5>
                <div className="flex flex-col space-y-4 text-slate-500 text-lg">
                  <a href="#sobre" onClick={(e) => scrollToSection(e, 'sobre')} className="hover:text-cyan-600 transition-colors">Sobre</a>
                  <a href="#servicos" onClick={(e) => scrollToSection(e, 'servicos')} className="hover:text-cyan-600 transition-colors">Serviços</a>
                  <a href="#beneficios" onClick={(e) => scrollToSection(e, 'beneficios')} className="hover:text-cyan-600 transition-colors">Diferenciais</a>
                </div>
              </div>
              <div className="space-y-6">
                <h5 className="font-bold text-slate-900 uppercase tracking-widest text-sm">Contato</h5>
                <div className="flex flex-col space-y-4 text-slate-500 text-lg">
                   <p className="flex items-center"><Phone size={18} className="mr-3 text-cyan-600" /> {phoneNumber}</p>
                   <p className="flex items-center"><MapPin size={18} className="mr-3 text-cyan-600" /> Mooca, SP</p>
                </div>
              </div>
            </div>
          </div>
          <div className="pt-12 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center text-slate-400 text-sm font-medium">
            <p>&copy; {new Date().getFullYear()} Dra. Samantha Berriel. Todos os direitos reservados.</p>
            <div className="mt-4 md:mt-0 space-x-6 uppercase tracking-widest">
               <span>CRO-SP: Ativo</span>
            </div>
          </div>
        </div>
      </footer>
      
      {/* Botão flutuante WhatsApp Pulsante */}
      <a 
        href={`https://wa.me/55${phoneNumber.replace(/\D/g, '')}`}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-8 right-8 bg-green-500 text-white w-16 h-16 rounded-full shadow-[0_15px_35px_-5px_rgba(34,197,94,0.5)] z-[60] flex items-center justify-center transition-all hover:scale-110 active:scale-95 group"
      >
        <span className="absolute inset-0 bg-green-500 rounded-full animate-ping opacity-25"></span>
        <MessageCircle size={32} className="relative z-10" />
        <span className="absolute right-full mr-4 bg-white text-slate-900 px-4 py-2 rounded-xl text-sm font-bold shadow-xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">Falar no WhatsApp</span>
      </a>
    </div>
  );
};

export default App;
